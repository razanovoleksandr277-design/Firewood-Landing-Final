# Лендинг по продаже дров

Next.js 16 + TypeScript + Tailwind CSS 4. Заявки с формы уходят в Telegram через серверный endpoint `/api/order`.

## Запуск

```bash
npm install
cp .env.example .env.local   # заполните позже, сайт работает и без Telegram
npm run dev                  # http://localhost:3000
```

Продакшен: `npm run build && npm start`.

## Подключение Telegram-бота

1. В Telegram откройте **@BotFather** → `/newbot` → получите токен.
2. Напишите вашему боту любое сообщение (или добавьте его в группу/канал; для канала сделайте администратором).
3. Узнайте chat id: откройте `https://api.telegram.org/bot<ТОКЕН>/getUpdates` и найдите `"chat":{"id":...}` (для групп id отрицательный). Либо напишите боту **@userinfobot**.
4. Впишите в `.env.local` (локально) или в переменные окружения хостинга:
   ```
   TELEGRAM_BOT_TOKEN=...
   TELEGRAM_CHAT_ID=...
   ```
5. Перезапустите сервер и отправьте тестовую заявку.

Токен используется только на сервере (`src/lib/telegram.ts`) и никогда не попадает во frontend. Пока переменные не заданы, сайт работает: клиент видит «Заявку надіслано», а заявка пишется в лог сервера. При ошибке Telegram клиент видит только общее сообщение без технических деталей.

## Что заменить на реальное

- `src/lib/site-config.ts` — телефон, e-mail, адрес, часы работы, ссылка на Telegram, цены, список пород дров. Пустые поля на сайте не показываются.
- `src/components/Faq.tsx` — ответы общие; уточните сроки, районы доставки, способы оплаты.
- `NEXT_PUBLIC_SITE_URL` — адрес вашего сайта (для SEO, sitemap, robots).
- По желанию: реальные фото вместо SVG-поленницы (`src/components/WoodArt.tsx`), отзывы, сертификаты, гарантии — добавьте отдельным блоком только с реальными данными.

## Деплой

**Vercel (проще всего):** загрузите проект в GitHub → vercel.com → *Import Project* → в *Environment Variables* добавьте `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `NEXT_PUBLIC_SITE_URL` → Deploy. Домен подключается в *Settings → Domains*.

**Свой VPS:** `npm ci && npm run build`, затем `npm start` под `pm2` (`pm2 start npm --name dubly -- start`), а перед ним nginx как reverse proxy на порт 3000 + сертификат Let's Encrypt (`certbot --nginx`). Переменные окружения положите в `.env.local` рядом с проектом.

## Структура

- `src/app/api/order/route.ts` — endpoint: валидация, honeypot, rate limit (5 заявок / 10 мин с IP), отправка в Telegram.
- `src/lib/order.ts` — валидация (общая для клиента и сервера), нормализация украинских номеров.
- `src/components/` — Header, Hero, Prices, Advantages, HowToOrder, OrderForm, Faq, FinalCta, Footer.
