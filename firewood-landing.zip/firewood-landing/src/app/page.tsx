import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Prices from "@/components/Prices";
import Advantages from "@/components/Advantages";
import HowToOrder from "@/components/HowToOrder";
import OrderForm from "@/components/OrderForm";
import Faq from "@/components/Faq";
import FinalCta from "@/components/FinalCta";
import Footer from "@/components/Footer";
import { siteConfig } from "@/lib/site-config";

export default function Home() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: siteConfig.name,
    description: siteConfig.description,
    ...(siteConfig.phone ? { telephone: siteConfig.phone } : {}),
    ...(siteConfig.address ? { address: siteConfig.address } : {}),
    priceRange: `${siteConfig.prices.cubic}–${siteConfig.prices.stack} UAH`,
    makesOffer: [
      {
        "@type": "Offer",
        itemOffered: { "@type": "Product", name: "Дрова, кубічний метр" },
        price: siteConfig.prices.cubic,
        priceCurrency: "UAH",
      },
      {
        "@type": "Offer",
        itemOffered: { "@type": "Product", name: "Дрова, складометр укладених дров" },
        price: siteConfig.prices.stack,
        priceCurrency: "UAH",
      },
    ],
  };

  return (
    <>
      <Header />
      <main>
        <Hero />
        <Prices />
        <Advantages />
        <HowToOrder />
        <OrderForm />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />
    </>
  );
}
