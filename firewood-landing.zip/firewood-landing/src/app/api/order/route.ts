import { NextResponse } from "next/server";
import { validateOrder, type OrderPayload } from "@/lib/order";
import { sendOrderToTelegram } from "@/lib/telegram";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Простий rate-limit у пам'яті (достатньо для одного інстансу): 5 заявок / 10 хв з одного IP.
const WINDOW_MS = 10 * 60 * 1000;
const MAX_REQUESTS = 5;
const hits = new Map<string, number[]>();

function rateLimited(ip: string): boolean {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) {
    for (const [key, times] of hits) {
      if (times.every((t) => now - t >= WINDOW_MS)) hits.delete(key);
    }
  }
  return recent.length > MAX_REQUESTS;
}

const GENERIC_ERROR = "Не вдалося надіслати заявку. Спробуйте ще раз або зателефонуйте нам.";

export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    if (rateLimited(ip)) {
      return NextResponse.json(
        { ok: false, message: "Забагато спроб. Спробуйте трохи пізніше." },
        { status: 429 },
      );
    }

    let body: Partial<OrderPayload>;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ ok: false, message: GENERIC_ERROR }, { status: 400 });
    }

    // Honeypot: боти заповнюють приховане поле — вдаємо успіх, нічого не надсилаємо.
    if (body.website) return NextResponse.json({ ok: true });

    const errors = validateOrder(body);
    if (Object.keys(errors).length > 0) {
      return NextResponse.json(
        { ok: false, message: "Перевірте правильність заповнення форми.", errors },
        { status: 422 },
      );
    }

    const order: OrderPayload = {
      name: String(body.name),
      phone: String(body.phone),
      product: String(body.product),
      quantity: String(body.quantity),
      format: body.format as OrderPayload["format"],
      address: String(body.address),
      comment: String(body.comment ?? ""),
    };

    const result = await sendOrderToTelegram(order);

    if (result === "failed") {
      return NextResponse.json({ ok: false, message: GENERIC_ERROR }, { status: 502 });
    }

    if (result === "not_configured") {
      // Telegram ще не підключено: сайт працює без помилок, заявка фіксується в логах сервера.
      console.warn("[order] Telegram не налаштовано. Заявка:", JSON.stringify(order));
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[order] unexpected error:", err instanceof Error ? err.message : "unknown");
    return NextResponse.json({ ok: false, message: GENERIC_ERROR }, { status: 500 });
  }
}
