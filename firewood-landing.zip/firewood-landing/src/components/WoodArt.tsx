/**
 * Векторна поленниця: торці колод з річними кільцями, згенерована кодом.
 * Нуль завантажень, чітка на будь-якому екрані, не потребує сторонніх фото.
 * Детерміновано (без Math.random), щоб SSR і клієнт збігалися.
 */

const BARK = ["#3a2418", "#42281b", "#35200f", "#4a2d1c", "#2f1c12"];
const CORE = ["#b98a58", "#c39560", "#a97b4a", "#bf8f5a", "#b0824f"];

function pseudo(i: number, salt: number) {
  const x = Math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
  return x - Math.floor(x);
}

const r1 = (n: number) => Math.round(n * 10) / 10;

interface Log {
  cx: number;
  cy: number;
  r: number;
  i: number;
}

function buildLogs(cols: number, rows: number, r: number): Log[] {
  const logs: Log[] = [];
  const dx = r * 2 * 0.98;
  const dy = r * 1.74;
  let n = 0;
  for (let row = 0; row < rows; row++) {
    const offset = row % 2 ? r : 0;
    for (let col = 0; col < cols + 1; col++) {
      const jitter = (pseudo(n, 1) - 0.5) * r * 0.12;
      logs.push({
        cx: Math.round((col * dx + offset + jitter) * 10) / 10,
        cy: Math.round((row * dy + r) * 10) / 10,
        r: Math.round(r * (0.9 + pseudo(n, 2) * 0.16) * 10) / 10,
        i: n,
      });
      n++;
    }
  }
  return logs;
}

export default function WoodArt({
  className = "",
  rows = 6,
  cols = 9,
  radius = 46,
  id = "wood",
}: {
  className?: string;
  rows?: number;
  cols?: number;
  radius?: number;
  id?: string;
}) {
  const logs = buildLogs(cols, rows, radius);
  const w = cols * radius * 2 * 0.98 + radius * 2;
  const h = (rows - 1) * radius * 1.74 + radius * 2;

  return (
    <svg
      className={className}
      viewBox={`0 0 ${w.toFixed(0)} ${h.toFixed(0)}`}
      preserveAspectRatio="xMidYMid slice"
      role="img"
      aria-label="Складені колоди дров"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <radialGradient id={`${id}-shade`} cx="50%" cy="45%" r="60%">
          <stop offset="0%" stopColor="#000" stopOpacity="0" />
          <stop offset="100%" stopColor="#000" stopOpacity="0.55" />
        </radialGradient>
      </defs>
      <rect width={w} height={h} fill="#120c0a" />
      {logs.map((l) => {
        const bark = BARK[l.i % BARK.length];
        const core = CORE[Math.floor(pseudo(l.i, 3) * CORE.length)];
        const rings = 3 + Math.floor(pseudo(l.i, 4) * 2);
        const crack = pseudo(l.i, 5) > 0.45;
        const ang = pseudo(l.i, 6) * Math.PI * 2;
        const shift = l.r * 0.06;
        return (
          <g key={l.i}>
            <circle cx={l.cx} cy={l.cy} r={l.r} fill={bark} />
            <circle cx={l.cx} cy={l.cy} r={r1(l.r * 0.9)} fill={core} opacity={0.5 + pseudo(l.i, 7) * 0.35} />
            {Array.from({ length: rings }).map((_, k) => (
              <circle
                key={k}
                cx={r1(l.cx + Math.cos(ang) * shift * k * 0.4)}
                cy={r1(l.cy + Math.sin(ang) * shift * k * 0.4)}
                r={r1(l.r * (0.84 - (k * 0.78) / rings))}
                fill="none"
                stroke="#5a3a22"
                strokeOpacity={0.55}
                strokeWidth={1.4}
              />
            ))}
            <circle cx={l.cx} cy={l.cy} r={r1(l.r * 0.07)} fill="#4a2e1a" />
            {crack && (
              <line
                x1={l.cx}
                y1={l.cy}
                x2={r1(l.cx + Math.cos(ang) * l.r * 0.82)}
                y2={r1(l.cy + Math.sin(ang) * l.r * 0.82)}
                stroke="#2a180e"
                strokeWidth={1.6}
                strokeLinecap="round"
              />
            )}
          </g>
        );
      })}
      <rect width={w} height={h} fill={`url(#${id}-shade)`} />
    </svg>
  );
}
