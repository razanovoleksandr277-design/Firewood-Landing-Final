import WoodArt from "./WoodArt";
import { siteConfig } from "@/lib/site-config";

export default function Hero() {
  return (
    <section id="top" className="relative isolate flex min-h-[100svh] items-center overflow-hidden">
      <div className="absolute inset-0 -z-10" aria-hidden>
        <WoodArt className="h-full w-full scale-110 opacity-90" rows={6} cols={7} radius={66} id="hero" />
        <div className="absolute inset-0 bg-gradient-to-b from-bg/75 via-bg/60 to-bg" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_40%,rgba(125,37,37,0.35),transparent_60%)] animate-flicker" />
        <div className="absolute inset-0 grain" />
      </div>

      <div className="mx-auto w-full max-w-6xl px-5 pb-16 pt-28 md:pt-32">
        <p className="animate-fade-up mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-bg/50 px-4 py-1.5 text-xs uppercase tracking-[0.18em] text-muted backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full bg-accent-2" /> Дрова з доставкою
        </p>

        <h1 className="animate-fade-up max-w-4xl text-balance font-display text-[2.6rem] leading-[1.05] tracking-tight [animation-delay:80ms] sm:text-6xl md:text-7xl">
          Дрова для тепла <span className="text-accent-2">вашого дому</span>
        </h1>

        <p className="animate-fade-up mt-5 max-w-xl text-lg text-muted [animation-delay:160ms] md:text-xl">
          Якісні дрова для опалення. Зручне замовлення та доставка.
        </p>

        <div className="animate-fade-up mt-9 grid max-w-2xl gap-3 [animation-delay:240ms] sm:grid-cols-2">
          <PriceChip value={siteConfig.prices.cubic} unit="м³" />
          <PriceChip value={siteConfig.prices.stack} unit="складометр укладених дров" />
        </div>

        <div className="animate-fade-up mt-9 flex flex-col gap-3 [animation-delay:320ms] sm:flex-row">
          <a
            href="#order"
            className="inline-flex min-h-14 items-center justify-center rounded-full bg-accent px-9 text-lg font-medium shadow-[0_10px_40px_rgba(125,37,37,0.5)] transition hover:-translate-y-0.5 hover:bg-accent-2 active:translate-y-0"
          >
            Замовити дрова
          </a>
          <a
            href="#advantages"
            className="inline-flex min-h-14 items-center justify-center rounded-full border border-line bg-bg/40 px-9 text-lg backdrop-blur transition hover:border-muted/50 hover:bg-bg/70"
          >
            Дізнатися більше
          </a>
        </div>
      </div>
    </section>
  );
}

function PriceChip({ value, unit }: { value: number; unit: string }) {
  return (
    <div className="rounded-2xl border border-line bg-bg/60 px-6 py-5 backdrop-blur-md">
      <div className="font-display text-4xl text-text md:text-5xl">
        {value.toLocaleString("uk-UA").replace(/ /g, " ")} <span className="text-xl text-muted">грн</span>
      </div>
      <div className="mt-0.5 text-sm text-muted">/ {unit}</div>
    </div>
  );
}
