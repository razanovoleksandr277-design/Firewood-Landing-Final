"use client";

import { useEffect, useState } from "react";
import { siteConfig } from "@/lib/site-config";

const links = [
  { href: "#prices", label: "Ціни" },
  { href: "#advantages", label: "Переваги" },
  { href: "#how", label: "Як замовити" },
  { href: "#faq", label: "Питання" },
  { href: "#contacts", label: "Контакти" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open
          ? "border-b border-line bg-bg/90 backdrop-blur-md"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="flex items-center gap-2.5 font-display text-lg tracking-wide" onClick={() => setOpen(false)}>
          <span aria-hidden className="grid h-8 w-8 place-items-center rounded-full bg-accent text-sm shadow-[0_0_18px_rgba(163,58,50,0.45)]">
            🔥
          </span>
          {siteConfig.name}
        </a>

        <nav aria-label="Основна навігація" className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-sm text-muted transition-colors hover:text-text">
              {l.label}
            </a>
          ))}
          <a
            href="#order"
            className="rounded-full bg-accent px-5 py-2.5 text-sm font-medium transition hover:bg-accent-2"
          >
            Замовити
          </a>
        </nav>

        <button
          type="button"
          className="grid h-11 w-11 place-items-center rounded-full border border-line md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Закрити меню" : "Відкрити меню"}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="relative block h-3.5 w-5">
            <span className={`absolute left-0 h-0.5 w-5 bg-text transition-all ${open ? "top-1.5 rotate-45" : "top-0"}`} />
            <span className={`absolute left-0 top-1.5 h-0.5 w-5 bg-text transition-opacity ${open ? "opacity-0" : "opacity-100"}`} />
            <span className={`absolute left-0 h-0.5 w-5 bg-text transition-all ${open ? "top-1.5 -rotate-45" : "top-3"}`} />
          </span>
        </button>
      </div>

      <div
        id="mobile-menu"
        className={`md:hidden ${open ? "visible opacity-100" : "invisible opacity-0"} fixed inset-x-0 top-16 bottom-0 bg-bg/98 px-5 pt-6 transition-opacity duration-300`}
      >
        <nav aria-label="Мобільна навігація" className="flex flex-col">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="border-b border-line py-4 font-display text-2xl"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#order"
            onClick={() => setOpen(false)}
            className="mt-8 rounded-full bg-accent py-4 text-center text-lg font-medium shadow-[0_8px_30px_rgba(125,37,37,0.45)]"
          >
            Замовити дрова
          </a>
        </nav>
      </div>
    </header>
  );
}
