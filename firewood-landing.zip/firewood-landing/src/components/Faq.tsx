import Reveal from "./Reveal";

/**
 * Відповіді навмисно загальні й не містять вигаданих умов.
 * TODO: уточніть їх під ваш бізнес (райони доставки, терміни, оплата).
 */
const faq = [
  {
    q: "Яка різниця між кубічним метром і складометром?",
    a: "Кубічний метр — це об’єм дров насипом. Складометр — це об’єм дров, акуратно укладених у штабель. Обидва формати доступні для замовлення за цінами, вказаними на сайті.",
  },
  {
    q: "Як швидко ви зв’яжетеся після заявки?",
    a: "Ми передзвонимо після отримання заявки, щоб уточнити деталі й погодити доставку. Точні терміни відповіді можна вказати тут.",
  },
  {
    q: "Як відбувається доставка?",
    a: "Дрова доставляються за адресою, яку ви вказали в заявці. Вартість і час доставки уточнюються під час підтвердження замовлення.",
  },
  {
    q: "Які способи оплати?",
    a: "Способи оплати обговорюються під час підтвердження замовлення. Тут можна додати конкретні варіанти — готівка, картка тощо.",
  },
  {
    q: "Чи можна замовити певну породу деревини?",
    a: "Так, у формі заявки можна вибрати тип дров або вказати побажання в коментарі. Наявність уточнимо під час дзвінка.",
  },
];

export default function Faq() {
  return (
    <section id="faq" className="bg-bg-2 py-20 md:py-28">
      <div className="mx-auto max-w-3xl px-5">
        <Reveal className="text-center">
          <h2 className="font-display text-4xl md:text-5xl">Часті питання</h2>
        </Reveal>

        <div className="mt-12 space-y-3">
          {faq.map((item, i) => (
            <Reveal key={item.q} delay={i * 60}>
              <details className="group rounded-2xl border border-line bg-bg/60 transition open:border-accent-2/40 open:bg-bg">
                <summary className="flex min-h-16 cursor-pointer items-center justify-between gap-4 px-6 py-4 text-left text-lg">
                  {item.q}
                  <span
                    aria-hidden
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-line text-xl leading-none text-accent-2 transition-transform duration-300 group-open:rotate-45"
                  >
                    +
                  </span>
                </summary>
                <p className="px-6 pb-6 leading-relaxed text-muted">{item.a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
