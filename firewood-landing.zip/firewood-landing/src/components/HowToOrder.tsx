import Reveal from "./Reveal";

const steps = [
  { title: "Залиште заявку", text: "Заповніть коротку форму: що, скільки і куди привезти." },
  { title: "Ми зателефонуємо", text: "Уточнимо деталі, підтвердимо ціну, час і умови доставки." },
  { title: "Отримайте дрова", text: "Привеземо замовлення за вашою адресою у погоджений час." },
];

export default function HowToOrder() {
  return (
    <section id="how" className="bg-bg-2 py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-4xl md:text-5xl">Як замовити</h2>
          <p className="mt-4 text-muted">Три простих кроки від заявки до тепла вдома.</p>
        </Reveal>

        <ol className="mt-14 grid gap-6 md:grid-cols-3">
          {steps.map((s, i) => (
            <Reveal as="li" key={s.title} delay={i * 120} className="relative">
              <div className="h-full rounded-3xl border border-line bg-bg/60 p-7">
                <span className="font-display text-6xl leading-none text-accent-2/80" aria-hidden>
                  {i + 1}
                </span>
                <h3 className="mt-5 font-display text-2xl">
                  <span className="sr-only">Крок {i + 1}: </span>
                  {s.title}
                </h3>
                <p className="mt-3 leading-relaxed text-muted">{s.text}</p>
              </div>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}
