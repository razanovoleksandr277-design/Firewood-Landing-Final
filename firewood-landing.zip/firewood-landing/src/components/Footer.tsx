import { siteConfig } from "@/lib/site-config";

export default function Footer() {
  const { phone, phoneDisplay, email, address, workingHours, telegram } = siteConfig;
  const hasContacts = phone || email || address || workingHours || telegram;

  return (
    <footer id="contacts" className="border-t border-line bg-bg-2 py-14">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 md:grid-cols-2">
        <div>
          <p className="font-display text-2xl">{siteConfig.name}</p>
          <p className="mt-3 max-w-sm text-muted">Якісні дрова для опалення. Зручне замовлення та доставка.</p>
        </div>

        <div>
          <h2 className="font-display text-xl">Контакти</h2>
          {hasContacts ? (
            <ul className="mt-4 space-y-2 text-muted">
              {phone && (
                <li>
                  <a href={`tel:${phone}`} className="inline-block py-1 transition hover:text-text">
                    {phoneDisplay ?? phone}
                  </a>
                </li>
              )}
              {email && (
                <li>
                  <a href={`mailto:${email}`} className="inline-block py-1 transition hover:text-text">
                    {email}
                  </a>
                </li>
              )}
              {telegram && (
                <li>
                  <a href={telegram} target="_blank" rel="noopener noreferrer" className="inline-block py-1 transition hover:text-text">
                    Telegram
                  </a>
                </li>
              )}
              {address && <li>{address}</li>}
              {workingHours && <li>{workingHours}</li>}
            </ul>
          ) : (
            // TODO: заповніть контакти у src/lib/site-config.ts — цей блок зникне автоматично
            <p className="mt-4 text-muted">
              Зв’яжіться з нами через форму замовлення — ми передзвонимо вам.{" "}
              <a href="#order" className="text-accent-2 underline underline-offset-4">
                Залишити заявку
              </a>
            </p>
          )}
        </div>
      </div>

      <div className="mx-auto mt-10 max-w-6xl border-t border-line px-5 pt-6 text-sm text-muted/80">
        © {new Date().getFullYear()} {siteConfig.name}. Усі права захищено.
      </div>
    </footer>
  );
}
