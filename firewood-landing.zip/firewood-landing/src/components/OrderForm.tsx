"use client";

import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { validateOrder, type OrderErrors, type OrderFormat, type OrderPayload } from "@/lib/order";
import { woodTypes } from "@/lib/site-config";
import { SELECT_FORMAT_EVENT } from "./SelectFormatButton";
import Reveal from "./Reveal";

type Values = Omit<OrderPayload, "website">;
type Status = "idle" | "sending" | "success" | "error";

const empty: Values = {
  name: "",
  phone: "",
  product: "",
  quantity: "",
  format: "cubic",
  address: "",
  comment: "",
};

const inputBase =
  "w-full rounded-xl border bg-bg px-4 py-3.5 text-base text-text placeholder:text-muted/60 transition focus:border-accent-2 focus:outline-none focus:ring-2 focus:ring-accent-2/30";

export default function OrderForm() {
  const uid = useId();
  const [values, setValues] = useState<Values>(empty);
  const [errors, setErrors] = useState<OrderErrors>({});
  const [touched, setTouched] = useState<Partial<Record<keyof Values, boolean>>>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverMessage, setServerMessage] = useState("");
  const honeypot = useRef<HTMLInputElement>(null);
  const successRef = useRef<HTMLDivElement>(null);

  // Кнопки «Замовити» в блоці цін передають сюди обраний формат.
  useEffect(() => {
    const handler = (e: Event) => {
      const fmt = (e as CustomEvent<OrderFormat>).detail;
      if (fmt === "cubic" || fmt === "stack") {
        setValues((v) => ({ ...v, format: fmt }));
        setStatus((s) => (s === "success" ? "idle" : s));
      }
    };
    window.addEventListener(SELECT_FORMAT_EVENT, handler);
    return () => window.removeEventListener(SELECT_FORMAT_EVENT, handler);
  }, []);

  useEffect(() => {
    if (status === "success") successRef.current?.focus();
  }, [status]);

  function update<K extends keyof Values>(key: K, value: Values[K]) {
    const next = { ...values, [key]: value };
    setValues(next);
    if (touched[key]) {
      setErrors((prev) => ({ ...prev, [key]: validateOrder(next)[key] }));
    }
  }

  function blur(key: keyof Values) {
    setTouched((t) => ({ ...t, [key]: true }));
    setErrors((prev) => ({ ...prev, [key]: validateOrder(values)[key] }));
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (status === "sending") return;

    const found = validateOrder(values);
    setErrors(found);
    setTouched({ name: true, phone: true, product: true, quantity: true, format: true, address: true, comment: true });

    const firstKey = Object.keys(found)[0];
    if (firstKey) {
      document.getElementById(`${uid}-${firstKey}`)?.focus();
      return;
    }

    setStatus("sending");
    setServerMessage("");
    try {
      const res = await fetch("/api/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...values, website: honeypot.current?.value ?? "" }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        message?: string;
        errors?: OrderErrors;
      };

      if (res.ok && data.ok) {
        setValues(empty);
        setErrors({});
        setTouched({});
        setStatus("success");
        return;
      }
      if (data.errors) setErrors(data.errors);
      setServerMessage(data.message || "Не вдалося надіслати заявку. Спробуйте ще раз.");
      setStatus("error");
    } catch {
      setServerMessage("Немає зв’язку з сервером. Перевірте інтернет і спробуйте ще раз.");
      setStatus("error");
    }
  }

  const fieldId = (k: string) => `${uid}-${k}`;
  const errId = (k: string) => `${uid}-${k}-err`;
  const border = (k: keyof Values) => (errors[k] ? "border-red-400/70" : "border-line");
  const aria = (k: keyof Values) =>
    ({
      "aria-invalid": errors[k] ? true : undefined,
      "aria-describedby": errors[k] ? errId(k) : undefined,
    }) as const;

  return (
    <section id="order" className="relative bg-bg py-20 md:py-28">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent-2/50 to-transparent"
      />
      <div className="mx-auto max-w-3xl px-5">
        <Reveal className="text-center">
          <h2 className="font-display text-4xl md:text-5xl">Замовити дрова</h2>
          <p className="mt-4 text-muted">Залиште заявку — ми зв’яжемося з вами, щоб підтвердити замовлення.</p>
        </Reveal>

        <Reveal delay={100}>
          <div className="mt-10 rounded-3xl border border-line bg-gradient-to-b from-bg-2 to-bg p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] sm:p-9">
            {status === "success" ? (
              <div
                ref={successRef}
                tabIndex={-1}
                role="status"
                className="flex flex-col items-center py-8 text-center outline-none"
              >
                <span className="grid h-20 w-20 place-items-center rounded-full bg-accent/50 shadow-[0_0_50px_rgba(163,58,50,0.55)]">
                  <svg viewBox="0 0 24 24" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d="m5 12.5 4.5 4.5L19 7.5" />
                  </svg>
                </span>
                <h3 className="mt-6 font-display text-3xl">Заявку надіслано!</h3>
                <p className="mt-3 max-w-md text-muted">
                  Дякуємо за замовлення. Ми зателефонуємо вам найближчим часом, щоб уточнити деталі.
                </p>
                <button
                  type="button"
                  onClick={() => setStatus("idle")}
                  className="mt-8 min-h-12 rounded-full border border-line px-7 transition hover:border-muted/60"
                >
                  Надіслати ще одну заявку
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
                {/* Honeypot для ботів: приховано від людей і скрінрідерів */}
                <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                  <label>
                    Website
                    <input ref={honeypot} type="text" name="website" tabIndex={-1} autoComplete="off" />
                  </label>
                </div>

                <Field id={fieldId("name")} label="Ім’я" error={errors.name} errId={errId("name")}>
                  <input
                    id={fieldId("name")}
                    name="name"
                    type="text"
                    autoComplete="name"
                    placeholder="Як до вас звертатися"
                    value={values.name}
                    onChange={(e) => update("name", e.target.value)}
                    onBlur={() => blur("name")}
                    className={`${inputBase} ${border("name")}`}
                    {...aria("name")}
                  />
                </Field>

                <Field id={fieldId("phone")} label="Номер телефону" error={errors.phone} errId={errId("phone")}>
                  <input
                    id={fieldId("phone")}
                    name="phone"
                    type="tel"
                    inputMode="tel"
                    autoComplete="tel"
                    placeholder="+380 50 123 45 67"
                    value={values.phone}
                    onChange={(e) => update("phone", e.target.value)}
                    onBlur={() => blur("phone")}
                    className={`${inputBase} ${border("phone")}`}
                    {...aria("phone")}
                  />
                </Field>

                <Field id={fieldId("product")} label="Тип дров" error={errors.product} errId={errId("product")}>
                  <select
                    id={fieldId("product")}
                    name="product"
                    value={values.product}
                    onChange={(e) => update("product", e.target.value)}
                    onBlur={() => blur("product")}
                    className={`${inputBase} ${border("product")} appearance-none bg-[right_1rem_center] bg-no-repeat pr-10`}
                    style={{
                      backgroundImage:
                        "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23B8A69B' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")",
                    }}
                    {...aria("product")}
                  >
                    <option value="" disabled>
                      Оберіть тип дров
                    </option>
                    {woodTypes.map((w) => (
                      <option key={w} value={w}>
                        {w}
                      </option>
                    ))}
                    <option value="Інше (вкажу в коментарі)">Інше (вкажу в коментарі)</option>
                  </select>
                </Field>

                <Field id={fieldId("quantity")} label="Кількість" error={errors.quantity} errId={errId("quantity")}>
                  <input
                    id={fieldId("quantity")}
                    name="quantity"
                    type="text"
                    inputMode="decimal"
                    autoComplete="off"
                    placeholder="Напр. 5"
                    value={values.quantity}
                    onChange={(e) => update("quantity", e.target.value)}
                    onBlur={() => blur("quantity")}
                    className={`${inputBase} ${border("quantity")}`}
                    {...aria("quantity")}
                  />
                </Field>

                <fieldset className="sm:col-span-2">
                  <legend className="mb-2 text-sm text-muted">Формат</legend>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {(
                      [
                        { v: "cubic", t: "Кубічний метр", s: "3000 грн / м³" },
                        { v: "stack", t: "Складометр", s: "3300 грн / складометр" },
                      ] as const
                    ).map((o) => (
                      <label
                        key={o.v}
                        className={`flex min-h-14 cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 transition has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-accent-2/50 ${
                          values.format === o.v ? "border-accent-2 bg-accent/25" : "border-line hover:border-muted/40"
                        }`}
                      >
                        <input
                          type="radio"
                          name="format"
                          value={o.v}
                          checked={values.format === o.v}
                          onChange={() => update("format", o.v)}
                          className="sr-only"
                        />
                        <span
                          aria-hidden
                          className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border ${
                            values.format === o.v ? "border-accent-2" : "border-muted/50"
                          }`}
                        >
                          {values.format === o.v && <span className="h-2.5 w-2.5 rounded-full bg-accent-2" />}
                        </span>
                        <span>
                          <span className="block">{o.t}</span>
                          <span className="block text-sm text-muted">{o.s}</span>
                        </span>
                      </label>
                    ))}
                  </div>
                  {errors.format && (
                    <p id={errId("format")} role="alert" className="mt-2 text-sm text-red-300">
                      {errors.format}
                    </p>
                  )}
                </fieldset>

                <div className="sm:col-span-2">
                  <Field id={fieldId("address")} label="Адреса доставки" error={errors.address} errId={errId("address")}>
                    <input
                      id={fieldId("address")}
                      name="address"
                      type="text"
                      autoComplete="street-address"
                      placeholder="Місто, вулиця, номер будинку"
                      value={values.address}
                      onChange={(e) => update("address", e.target.value)}
                      onBlur={() => blur("address")}
                      className={`${inputBase} ${border("address")}`}
                      {...aria("address")}
                    />
                  </Field>
                </div>

                <div className="sm:col-span-2">
                  <Field
                    id={fieldId("comment")}
                    label="Коментар"
                    optional
                    error={errors.comment}
                    errId={errId("comment")}
                  >
                    <textarea
                      id={fieldId("comment")}
                      name="comment"
                      rows={3}
                      placeholder="Побажання щодо доставки, зручний час для дзвінка тощо"
                      value={values.comment}
                      onChange={(e) => update("comment", e.target.value)}
                      onBlur={() => blur("comment")}
                      className={`${inputBase} ${border("comment")} resize-y`}
                      {...aria("comment")}
                    />
                  </Field>
                </div>

                {status === "error" && (
                  <p
                    role="alert"
                    className="rounded-xl border border-red-400/40 bg-red-950/40 px-4 py-3 text-sm text-red-200 sm:col-span-2"
                  >
                    {serverMessage}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="inline-flex min-h-14 items-center justify-center gap-3 rounded-full bg-accent text-lg font-medium shadow-[0_10px_40px_rgba(125,37,37,0.5)] transition hover:bg-accent-2 disabled:cursor-wait disabled:opacity-70 sm:col-span-2"
                >
                  {status === "sending" && (
                    <span className="h-5 w-5 animate-spin rounded-full border-2 border-text/30 border-t-text" aria-hidden />
                  )}
                  {status === "sending" ? "Надсилаємо…" : "Надіслати заявку"}
                </button>

                <p className="text-center text-xs text-muted sm:col-span-2">
                  Надсилаючи заявку, ви погоджуєтеся на обробку контактних даних для зв’язку щодо замовлення.
                </p>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Field({
  id,
  label,
  error,
  errId,
  optional,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  errId: string;
  optional?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm text-muted">
        {label}
        {optional && <span className="ml-1 text-muted/60">(необов’язково)</span>}
      </label>
      {children}
      {error && (
        <p id={errId} role="alert" className="mt-2 text-sm text-red-300">
          {error}
        </p>
      )}
    </div>
  );
}
