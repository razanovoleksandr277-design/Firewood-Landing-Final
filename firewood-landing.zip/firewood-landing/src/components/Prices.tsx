import Reveal from "./Reveal";
import SelectFormatButton from "./SelectFormatButton";
import { siteConfig } from "@/lib/site-config";

const cards = [
  {
    format: "cubic" as const,
    title: "Кубічний метр",
    price: siteConfig.prices.cubic,
    unit: "/ м³",
    note: "Класичний варіант — дрова насипом.",
    featured: false,
  },
  {
    format: "stack" as const,
    title: "Складометр укладених дров",
    price: siteConfig.prices.stack,
    unit: "/ складометр",
    note: "Дрова, акуратно укладені в штабель.",
    featured: true,
  },
];

export default function Prices() {
  return (
    <section id="prices" className="relative bg-bg-2 py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-4xl md:text-5xl">Наші ціни</h2>
          <p className="mt-4 text-muted">Прозорі ціни без прихованих доплат за формат — оберіть зручний для вас.</p>
        </Reveal>

        <div className="mx-auto mt-12 grid max-w-4xl gap-6 md:grid-cols-2">
          {cards.map((c, i) => (
            <Reveal key={c.format} delay={i * 120}>
              <article
                className={`relative h-full overflow-hidden rounded-3xl border p-8 transition duration-300 hover:-translate-y-1 ${
                  c.featured
                    ? "border-accent-2/50 bg-gradient-to-b from-bg-3 to-bg shadow-[0_20px_60px_rgba(125,37,37,0.3)]"
                    : "border-line bg-gradient-to-b from-bg-3/70 to-bg shadow-[0_20px_50px_rgba(0,0,0,0.35)]"
                }`}
              >
                <div
                  aria-hidden
                  className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-accent/25 blur-3xl"
                />
                <h3 className="relative font-display text-2xl">{c.title}</h3>
                <p className="relative mt-1 text-sm text-muted">{c.note}</p>
                <p className="relative mt-8 flex items-baseline gap-2">
                  <span className="font-display text-6xl leading-none tracking-tight md:text-7xl">
                    {c.price.toLocaleString("uk-UA").replace(/ /g, " ")}
                  </span>
                  <span className="text-xl text-muted">грн</span>
                </p>
                <p className="relative mt-1 text-lg text-accent-2">{c.unit}</p>
                <SelectFormatButton
                  format={c.format}
                  className={`relative mt-8 inline-flex min-h-14 w-full items-center justify-center rounded-full text-lg font-medium transition ${
                    c.featured
                      ? "bg-accent shadow-[0_10px_30px_rgba(125,37,37,0.45)] hover:bg-accent-2"
                      : "border border-accent-2/60 hover:bg-accent/30"
                  }`}
                >
                  Замовити
                </SelectFormatButton>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
