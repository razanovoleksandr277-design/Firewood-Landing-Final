import Reveal from "./Reveal";
import WoodArt from "./WoodArt";

export default function FinalCta() {
  return (
    <section className="relative isolate overflow-hidden py-24 md:py-32">
      <div className="absolute inset-0 -z-10" aria-hidden>
        <WoodArt className="h-full w-full opacity-40" rows={4} cols={6} radius={72} id="cta" />
        <div className="absolute inset-0 bg-gradient-to-b from-bg via-bg/75 to-bg" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_50%,rgba(125,37,37,0.4),transparent_65%)]" />
      </div>
      <Reveal className="mx-auto max-w-2xl px-5 text-center">
        <h2 className="font-display text-4xl leading-tight md:text-6xl">Готові зустріти холода в теплі?</h2>
        <p className="mt-5 text-lg text-muted">Залиште заявку — решту ми візьмемо на себе.</p>
        <a
          href="#order"
          className="mt-9 inline-flex min-h-14 items-center justify-center rounded-full bg-accent px-10 text-lg font-medium shadow-[0_10px_40px_rgba(125,37,37,0.55)] transition hover:-translate-y-0.5 hover:bg-accent-2"
        >
          Замовити дрова
        </a>
      </Reveal>
    </section>
  );
}
