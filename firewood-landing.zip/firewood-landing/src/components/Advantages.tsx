import Reveal from "./Reveal";

const items = [
  {
    title: "Якість",
    text: "Дрова для опалення, які добре горять і віддають тепло. Тип деревини ви обираєте під своє завдання.",
    icon: (
      <path d="M12 3c3 4 5 6.5 5 10a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5.3 1.5 1 2.3 2 2.5C10.5 8.5 11 6 12 3Z" />
    ),
  },
  {
    title: "Зручне замовлення",
    text: "Одна проста форма на сайті — без реєстрацій і зайвих кроків. Ми самі зв’яжемося, щоб уточнити деталі.",
    icon: (
      <>
        <rect x="5" y="3" width="14" height="18" rx="2.5" />
        <path d="M9 8h6M9 12h6M9 16h3" />
      </>
    ),
  },
  {
    title: "Доставка",
    text: "Привеземо дрова за вказаною адресою. Умови та вартість доставки уточнюються під час підтвердження заявки.",
    icon: (
      <>
        <path d="M3 7h11v9H3zM14 10h4l3 3v3h-7" />
        <circle cx="7" cy="17.5" r="1.8" />
        <circle cx="17" cy="17.5" r="1.8" />
      </>
    ),
  },
];

export default function Advantages() {
  return (
    <section id="advantages" className="grain relative bg-bg py-20 md:py-28">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal className="max-w-2xl">
          <h2 className="font-display text-4xl md:text-5xl">Чому обирають нас</h2>
          <p className="mt-4 text-muted">Тепло в оселі має починатися без клопоту.</p>
        </Reveal>

        <ul className="mt-12 grid gap-5 md:grid-cols-3">
          {items.map((it, i) => (
            <Reveal as="li" key={it.title} delay={i * 110}>
              <div className="h-full rounded-3xl border border-line bg-gradient-to-b from-bg-2 to-bg p-7 transition duration-300 hover:border-accent-2/40">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-accent/40 text-text shadow-[0_0_24px_rgba(125,37,37,0.4)]">
                  <svg
                    viewBox="0 0 24 24"
                    className="h-6 w-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden
                  >
                    {it.icon}
                  </svg>
                </span>
                <h3 className="mt-6 font-display text-2xl">{it.title}</h3>
                <p className="mt-3 leading-relaxed text-muted">{it.text}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
