"use client";

import type { ReactNode } from "react";
import type { OrderFormat } from "@/lib/order";

export const SELECT_FORMAT_EVENT = "order:select-format";

/** Кнопка «Замовити»: передає обраний формат у форму та прокручує до неї. */
export default function SelectFormatButton({
  format,
  className,
  children,
}: {
  format: OrderFormat;
  className?: string;
  children: ReactNode;
}) {
  return (
    <a
      href="#order"
      className={className}
      onClick={() => {
        window.dispatchEvent(new CustomEvent(SELECT_FORMAT_EVENT, { detail: format }));
      }}
    >
      {children}
    </a>
  );
}
