/** Спільна логіка валідації — використовується і на клієнті, і на сервері. */

export type OrderFormat = "cubic" | "stack";

export interface OrderPayload {
  name: string;
  phone: string;
  product: string;
  quantity: string;
  format: OrderFormat;
  address: string;
  comment: string;
  /** Honeypot: реальні користувачі це поле не бачать і не заповнюють. */
  website?: string;
}

export type OrderErrors = Partial<Record<keyof OrderPayload, string>>;

export const formatLabels: Record<OrderFormat, string> = {
  cubic: "Кубічний метр (м³)",
  stack: "Складометр укладених дров",
};

/** Нормалізує український номер до вигляду +380XXXXXXXXX. Повертає null, якщо номер некоректний. */
export function normalizeUaPhone(raw: string): string | null {
  let digits = raw.replace(/\D/g, "");
  if (digits.startsWith("380") && digits.length === 12) {
    // ok
  } else if (digits.startsWith("80") && digits.length === 11) {
    digits = "3" + digits;
  } else if (digits.startsWith("0") && digits.length === 10) {
    digits = "38" + digits;
  } else {
    return null;
  }
  // Код оператора/регіону не може починатися з 0 чи 1 після 380
  if (!/^380[2-9]\d{8}$/.test(digits)) return null;
  return "+" + digits;
}

export function validateOrder(data: Partial<OrderPayload>): OrderErrors {
  const errors: OrderErrors = {};

  const name = (data.name ?? "").trim();
  if (name.length < 2) errors.name = "Вкажіть ім’я (мінімум 2 символи)";
  else if (name.length > 80) errors.name = "Ім’я занадто довге";

  const phone = (data.phone ?? "").trim();
  if (!phone) errors.phone = "Вкажіть номер телефону";
  else if (!normalizeUaPhone(phone))
    errors.phone = "Введіть коректний номер, напр. +380 50 123 45 67";

  const product = (data.product ?? "").trim();
  if (!product) errors.product = "Оберіть або вкажіть тип дров";
  else if (product.length > 120) errors.product = "Занадто довгий текст";

  const qty = (data.quantity ?? "").trim().replace(",", ".");
  const qtyNum = Number(qty);
  if (!qty) errors.quantity = "Вкажіть кількість";
  else if (!Number.isFinite(qtyNum) || qtyNum <= 0)
    errors.quantity = "Кількість має бути числом більше нуля";
  else if (qtyNum > 1000) errors.quantity = "Для великих замовлень зателефонуйте нам";

  if (data.format !== "cubic" && data.format !== "stack")
    errors.format = "Оберіть формат вимірювання";

  const address = (data.address ?? "").trim();
  if (address.length < 5) errors.address = "Вкажіть адресу доставки (місто, вулиця, номер)";
  else if (address.length > 250) errors.address = "Адреса занадто довга";

  if ((data.comment ?? "").length > 1000) errors.comment = "Коментар занадто довгий (до 1000 символів)";

  return errors;
}
