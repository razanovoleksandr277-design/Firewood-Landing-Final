/**
 * Єдине місце для контактних даних і тексту, який потрібно замінити на реальний.
 * Порожні значення (null) не відображаються на сайті.
 */
export const siteConfig = {
  name: "Дрова для дому",
  title: "Дрова для опалення з доставкою — замовити дрова",
  description:
    "Якісні дрова для опалення. Зручне замовлення та доставка. 3000 грн за м³ або 3300 грн за складометр укладених дров.",

  // TODO: замініть на реальні дані
  phone: null as string | null, // напр. "+380XXXXXXXXX"
  phoneDisplay: null as string | null, // напр. "+38 (0XX) XXX-XX-XX"
  email: null as string | null,
  address: null as string | null,
  workingHours: null as string | null, // напр. "Пн–Нд, 08:00–20:00"
  telegram: null as string | null, // напр. "https://t.me/your_username"

  prices: {
    cubic: 3000,
    stack: 3300,
  },
};

export const woodTypes = [
  "Дуб",
  "Граб",
  "Ясен",
  "Береза",
  "Вільха",
  "Сосна",
  "Мікс / за наявністю",
] as const;
