import "server-only";
import { formatLabels, normalizeUaPhone, type OrderPayload } from "./order";

export type TelegramResult = "sent" | "not_configured" | "failed";

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export function buildMessage(o: OrderPayload): string {
  const phone = normalizeUaPhone(o.phone) ?? o.phone;
  const lines = [
    "🔥 <b>Нова заявка на дрова</b>",
    "",
    `👤 <b>Ім’я:</b> ${escapeHtml(o.name.trim())}`,
    `📞 <b>Телефон:</b> ${escapeHtml(phone)}`,
    `🪵 <b>Товар:</b> ${escapeHtml(o.product.trim())}`,
    `📦 <b>Кількість:</b> ${escapeHtml(o.quantity.trim())}`,
    `📐 <b>Формат:</b> ${escapeHtml(formatLabels[o.format])}`,
    `📍 <b>Адреса:</b> ${escapeHtml(o.address.trim())}`,
    `💬 <b>Коментар:</b> ${o.comment.trim() ? escapeHtml(o.comment.trim()) : "—"}`,
  ];
  return lines.join("\n");
}

/**
 * Надсилає заявку в Telegram. Ніколи не кидає виняток — повертає статус.
 * Якщо змінні середовища не задані — повертає "not_configured".
 */
export async function sendOrderToTelegram(order: OrderPayload): Promise<TelegramResult> {
  const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
  const chatId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (!token || !chatId) return "not_configured";

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10_000);
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: buildMessage(order),
        parse_mode: "HTML",
        disable_web_page_preview: true,
      }),
      signal: controller.signal,
      cache: "no-store",
    });
    if (!res.ok) {
      // Не логуємо токен: URL у лог не потрапляє, лише статус і опис помилки.
      const body = await res.json().catch(() => ({}));
      console.error("[telegram] sendMessage failed:", res.status, body?.description ?? "");
      return "failed";
    }
    return "sent";
  } catch (err) {
    console.error("[telegram] request error:", err instanceof Error ? err.name : "unknown");
    return "failed";
  } finally {
    clearTimeout(timer);
  }
}
